/*  asciidefs.h - a header file containing some necessary #defines for 
    parseDice().  Defines some ascii codes, and some flags for internal
    use.

    Copyright (C) 1999 Jeff Frasca <ph43drus@home.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if the file "GPL" isn't at the root of the 
    source tree, write to: 
        the Free Software Foundation, Inc. 
        59 Temple Place, Suite 330
        Boston, MA  02111-1307  USA

    Happy Hacking :)
*/

/* ascii codes */
#define NADA 48
#define EIN 49
#define ZWEI 50
#define DREI 51
#define VIER 52
#define FUNF 53
#define SECHS 54
#define SIEBEN 55
#define ACHT 56
#define NEUN 59
#define DAEY 100
#define PLUS 43
#define NEGA 45
#define ASTR 42
#define IX 120

/* bits used to determing last operation */
#define FPLUS 1
#define FNEGA 2
#define FASTR 4
#define FIX 8
#define FDAEY 16
