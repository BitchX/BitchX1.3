on #-msg 44 * {@lrm=[$1-];@lrmn=[$0]}

on #-send_msg 55 * {@lsm=[$1-];@lsmn=[$0]} 

on #-notice  66 * {@lrn=[$1-];@lrnn=[$0]}

on #-send_notice 77 * {@lsn=[$1-];@lsnn=[$0]}

alias uptime {/load ~/cyp/ans/uptime.ans}