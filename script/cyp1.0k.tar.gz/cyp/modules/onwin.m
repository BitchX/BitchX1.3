on ^window  "? *BitchX: Press Ctrl-F to see who left Ctrl-E to change to*" #
on ^window  "? *BitchX: Press Ctrl-K to join*" {xecho -b cypress press Ctrl-K to join.}
on ^window  "? *BitchX: Press ^F to see who left ^E to change to*" #
on ^window  "? *BitchX: Press ^K to join*" {xecho -b cypress press Ctrl-K to join.}
on ^306 * #
on ^305 * #